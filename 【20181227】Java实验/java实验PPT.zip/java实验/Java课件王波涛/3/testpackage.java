package t2;
import t1.*;
public class TestPackage
{
    public static void main(String args[])
    {
        new t1.Test1().print1(); 
    }
}
