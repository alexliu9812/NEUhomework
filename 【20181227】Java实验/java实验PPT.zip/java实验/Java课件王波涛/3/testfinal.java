     class testfinal 
     { 
        final int i;
        
        testfinal (int y)
        {
       //   i=0;
          i=y;
        }
        void func()
        {
          int y;
          i= 0;
        }
     }
