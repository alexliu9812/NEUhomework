package t1;
public class Test1
{
    public void print1()
    { System.out.println("This is a method in package t1");}
}


package t2;
public class Test2
{
    public static void main(String args[])
    {
        new t1.Test1().print1(); 
    }
}
