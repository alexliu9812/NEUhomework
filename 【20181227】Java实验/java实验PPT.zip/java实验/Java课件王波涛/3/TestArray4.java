public class TestArray4
{
    public static void main(String [] args)
    {
   int xx[][];
   xx=new int[3][4];

//   int xx[0][], int[] xx[1], int[] xx[2];
//   xx[0]=new int[3];
//   xx[1]=new int[2];
//   xx[2]=new int[1];

   xx[0][0] = 1;

	}
}