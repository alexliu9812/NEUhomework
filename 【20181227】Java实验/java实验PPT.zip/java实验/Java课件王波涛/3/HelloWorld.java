// This is the first java program
/**
 * Title: test1��<br>
 * Company: NEU ISE<br>
 * @author  AAA  bbb
 * @version 1.0
 */

public class HelloWorld
{
    int test(){
     int i=0;
     return i++;
   }
   public static void main(String[] args)
   {
    int i=0;
    byte b1 = 'a';
    float f1 = 0;
    char c = 'a';
    b1 = (byte)i;
    
    
    new HelloWorld().test();
  
     System.out.println("Hello world" +
        " test");
   }
}