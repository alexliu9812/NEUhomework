public class TestArray
{
    public static void main(String [] args)
    {
        int x[], x9[];
        int [][]y;
        int z[][] = new int[3][];
        int z1[][] = new int [3][2];
        int  x2[] =  {1,2,3};
        int []x1, x10[];
        
        z1[2][1] = 0;
		x=new int[100];
		for(int i=0;i<100;i++)
			{
				 System.out.println("x"+i+" is "+x[i]);
			}
			
			int[][] a = new int[10][10];
     int[][] b = new int[2][4];
     int[][] c = new int[3][];
     int[] d =  {1, 2, 3};
     int[] e = {1,2,3};
     int[][] f = {{1, 2, 3},{4, 5},{6}};

	}
}