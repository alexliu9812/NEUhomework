class Human{
   int age;
   Human(){
       age =10;
       System.out.println("A human has been created��");
   }

public static void main(String[] args){
   Human h1=new Human();
}
} 