class SimpleClass{
}