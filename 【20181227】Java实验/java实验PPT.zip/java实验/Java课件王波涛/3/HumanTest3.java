class HumanTest3{
int age;
int height;
 HumanTest3(int age, int h){
       age = age;
       height = h;
       System.out.println("A human class has been created��"+age);
   }

public static void main(String[] args){
   HumanTest3 h1=new HumanTest3(1,2);
   // HumanTest3 h1=new HumanTest3();
}


}