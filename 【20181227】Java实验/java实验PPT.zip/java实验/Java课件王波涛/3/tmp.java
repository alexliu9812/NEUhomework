class Human
{
    int age;
    char sex;
    Human(int age)
    {
        this.age=age;
    }

}

class Student extends Human
{
int i;
  Student(int age)
   {
      
      super(age);
      i=0;
   }
  
}
 