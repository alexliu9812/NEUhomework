public class MainTest
{
    public static void main(String[] args1)
    {
        System.out.print("The number of parameters is:"+args1.length);
        System.out.println();
        for(int i=0;i<args1.length;i++)
        {
            System.out.println(args1[i]);
        }
    }
}
