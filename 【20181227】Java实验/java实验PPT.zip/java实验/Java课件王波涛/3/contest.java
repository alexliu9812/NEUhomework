class  ConTest{
   ConTest(){
       System.out.println("A human has benn created��");
   }

   public static void main(String[] args){
       ConTest h1=new ConTest();
  }
} 
