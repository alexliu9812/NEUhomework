class  Human{
   String name;
   int age;
   
   public Human(){
       System.out.println("A human has benn created��");
   }
 
   public Human(String name){
           System.out.println("One Parameter. A human has benn created��");
           this.name=name;
   }
   
   public Human(String name,int age){  
       
           this(name);
           System.out.println("Two Parameters. A human has benn created��");      
           this.age=age;
   }


   public static void main(String[] args){
       Human h1=new Human();
       Human h2 = new Human("bob", 23);
  }
} 
