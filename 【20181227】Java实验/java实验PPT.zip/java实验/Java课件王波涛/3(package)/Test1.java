package t1;
public class Test1
{
    public void print1()
    { System.out.println("This is a method in package t1");}
}
