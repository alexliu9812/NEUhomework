package t2;
import t1.*;
import java.io.FileInputStream;
public class Test3
{
    public static void main(String args[])
    {
        new Test1().print1(); 
        
    }
}
