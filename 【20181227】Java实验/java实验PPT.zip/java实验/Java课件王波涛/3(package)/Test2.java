package t2;
//import t1.*;
import java.io.FileInputStream;
public class Test2
{
    public static void main(String args[])
    {
        new t1.Test1().print1(); 
        
    }
}
