/**
 * @(#)testString1.java
 *
 *
 * @author 
 * @version 1.00 2007/12/4
 */

public class testString1 {
        
    /**
     * Creates a new instance of <code>testString1</code>.
     */
    public testString1() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       	System.out.println(5+6+"A");
       	System.out.println(5+"A"+6);
       	System.out.println(5+"a"+6+7);

    }
}
