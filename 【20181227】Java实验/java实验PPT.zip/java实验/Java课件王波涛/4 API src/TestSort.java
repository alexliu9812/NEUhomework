import java.util.*;
public class TestSort
{
	public static void main(String[] args)
	{
		ArrayList al=new ArrayList();
		al.add(new Integer(1));
		al.add(new Integer(3));
		al.add(new Integer(2));
		System.out.println(al.toString()); //����ǰ
		Collections.sort(al); 
		System.out.println(al.toString()); //�����
	}
}