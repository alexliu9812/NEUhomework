/**
 * @(#)testString4.java
 *
 *
 * @author 
 * @version 1.00 2007/12/4
 */

public class testString4 {
        
    /**
     * Creates a new instance of <code>testString4</code>.
     */
    public testString4() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Happy".charAt(1));
        System.out.println("Happy".toUpperCase());
        System.out.println("Happy".toLowerCase());
        System.out.println("UnHappy".substring(2));
        System.out.println("û��Ǯ".substring(1));
        System.out.println("û��Ǯ".substring(1,2));
    }
}
