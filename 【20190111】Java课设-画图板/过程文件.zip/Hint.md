```flow
st=>start: 开始
e=>end: 结束
op1=>operation: 默认直接格式化和显示提示文字
op2=>operation: 清空提示内容并显示输入文字
op3=>operation: 格式化和显示提示文字
cond1=>condition: 获取焦点?
cond2=>condition: 失去焦点?
cond3=>condition: 程序结束？
cond4=>condition: 程序结束？

st->op1->cond1
cond1(yes)->op2->cond2
cond2(yes)->op3->cond4
cond4(no)->cond1
cond4(yes)->e
```

```flow
st=>start: 开始
e=>end: 结束
op1=>operation: 获取创建按钮
cond0=>condition: 没有获取到按钮？
op01=>operation: 报错并结束本函数执行下一段程序
op2=>operation: 获取按钮图片地址
cond1=>condition: 没有正常获取到地址？
op21=>operation: 设置地址为默认地址
op3=>operation: 获取按钮图片大小
cond2=>condition: 没有正常获取到大小？
op31=>operation: 设置大小为默认大小
op4=>operation: 获取提示信息
cond3=>condition: 没有正常获取到提示信息？
op41=>operation: 设置提示信息为空
op5=>operation: 绑定所有信息到按钮
op6=>operation: 返回按钮

st->op1->cond0
cond0(yes)->op01
cond0(no)->op2->cond1
cond1(yes)->op21->op3
cond1(no)->op3->cond2
cond2(yes)->op31->cond3
cond2(no)->op4->cond3
cond3(yes)->op41->op5->op6
cond3(no)->op5->op6
op6->e
```

