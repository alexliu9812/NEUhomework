#include <stdio.h>
#include <stdlib.h>
#define MAX 14
#define ERROR 1
#define OK 0
typedef struct edgeNode
{
	int data;
	struct edgeNode *next;
} EdgeNode;
typedef struct headNode
{
	int in;
	int data;
	EdgeNode *fnode;
} HeadNode,HeadList[MAX];
typedef struct
{
	HeadList headlist;
	int numEdges,numVertexes;
} Graph,*graph;

void initGraph(graph g);
int inputInfo(graph g,int tar,int in,int data,int first);
void printGraph(graph g);
int topGraph(graph g);
int main()
{
	Graph *g = (Graph *)malloc(sizeof(Graph));
	initGraph(g);
	printGraph(g);

	if(topGraph(g) == ERROR)
		printf("�л�·��\n");
	else
		printf("û�л�·��\n");

	free(g);
	getchar();
	return 0;
}
int topGraph(graph g)
{
	EdgeNode *e;
	int i,k,gettop;
	int top = 0 ;
	int count = 0;
	int *stack;
	stack = (int *)malloc(g->numVertexes * sizeof(int));
	for(i=0; i<g->numVertexes; i++)
		{
			if(g->headlist[i].in == 0) //�����Ϊ0�ģ���û����ȵĵ���ջ
				stack[++top] = i;
		}
	while(top)
		{
			gettop = stack[top--];
			printf("%d ",gettop);
			count++;
			for(e = g->headlist[gettop].fnode; e ; e=e->next)  //һ�α������������ٸ����ӽڵ�����
				{
					k = e->data;
					if(!(--g->headlist[k].in))
						stack[++top] = k;
				}
		}
	if(count < g->numVertexes)
		return ERROR;
	else
		return OK;
}
void printGraph(graph g)
{
	int i;
	printf("vertex:%d,edges:%d\n",g->numVertexes,g->numEdges);
	EdgeNode *e = (EdgeNode *)malloc(sizeof(EdgeNode));
	for(i=0; i<MAX; i++)
		{
			printf("[in:%d]%d",g->headlist[i].in,g->headlist[i].data);
			e = g->headlist[i].fnode;
			while(e != NULL)
				{
					printf("->%d",e->data);
					e = e->next;
				}
			printf("\n");
		}
	free(e);
}
void initGraph(graph g)
{
	g->numVertexes = MAX;
	g->numEdges = 0;
	int i;
	for(i=0; i<MAX; i++)
		{
			g->headlist[i].fnode = NULL;
		}
	inputInfo(g,0,0,0,4);
	inputInfo(g,0,0,0,5);
	inputInfo(g,0,0,0,11);

	inputInfo(g,1,0,1,2);
	inputInfo(g,1,0,1,4);
	inputInfo(g,1,0,1,8);

	inputInfo(g,2,2,2,5);
	inputInfo(g,2,2,2,6);
	inputInfo(g,2,2,2,9);

	inputInfo(g,3,0,3,2);
	inputInfo(g,3,0,3,13);

	inputInfo(g,4,2,4,7);

	inputInfo(g,5,3,5,8);
	inputInfo(g,5,3,5,12);

	inputInfo(g,6,1,6,5);

	inputInfo(g,7,2,7,-1);

	inputInfo(g,8,2,8,7);

	inputInfo(g,9,1,9,10);
	inputInfo(g,9,1,9,11);

	inputInfo(g,10,1,10,13);

	inputInfo(g,11,2,11,-1);

	inputInfo(g,12,1,12,9);

	inputInfo(g,13,2,13,-1);
}
int inputInfo(graph g,int tar,int in,int data,int first)
{
	g->numEdges++;

	if(first == -1)  //û�к�̵ı߽ڵ�
		{
			g->headlist[tar].in = in;
			g->headlist[tar].data = data;
			return 1;
		}

	if(!g->headlist[tar].fnode)  //�۲��Ƿ��Ѿ���ʼ��
		{
			g->headlist[tar].in = in;
			g->headlist[tar].data = data;
		}
	EdgeNode *e = (EdgeNode *)malloc(sizeof(EdgeNode));
	e->data = first;
	e->next = g->headlist[tar].fnode;
	g->headlist[tar].fnode = e;
	return 0;
}
