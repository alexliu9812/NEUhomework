#ifndef GRAPHMATRIX_H
#define GRAPHMATRIX_H
#include<iostream>
using namespace std;
const int maxn = 127;
template<class T>
class GraphMatrix
{
public:
    GraphMatrix(int p=0,int e=0):point_num(p),edge_num(e) {};
    bool InsertPoint(char x);
    void PrintGraph();
protected:
    char point_name[maxn];
    double gra[maxn][maxn];
    int point_num,edge_num;
};

template<class T>
bool GraphMatrix<T>::InsertPoint(char x)
{
    if(point_num==0)
    {
        point_num=1;
        point_name[0]=x;
    }
    else
    {
        point_name[point_num]=x;

        for(int i=0; i<point_num; i++)
        {
            cin>>gra[point_num][i];
            if(gra[point_num][i]!=0)
                edge_num++;
        }
        point_num++;
    }

}

template<class T>
void GraphMatrix<T>::PrintGraph()
{
    cout<<"Point number:"<<point_num<<endl;
    cout<<"edge number:"<<edge_num<<endl;
    /*cout<<"\t";
    for(int i=0; i<point_num+1; i++)
       cout<<point_name[i]<<"\t";
    for(int i=0; i<point_num+1; i++)
    {
       cout<<point_name[i]<<"\t";
       for(int j=0; j<point_num+1; j++)
       {
           cout<<gra[i][j]<<"\t";
       }
       cout<<endl;
    }
    */

}
#endif // GRAPHMATRIX_H
