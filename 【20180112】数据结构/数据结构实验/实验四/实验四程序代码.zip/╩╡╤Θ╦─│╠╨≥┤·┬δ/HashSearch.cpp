#include<bits/stdc++.h>
using namespace std;

const int HASH_SIZE=100;
vector<string> container;
struct hash_node
{
    int number;
    string key;
    hash_node* next;
    hash_node(string a="",int b=0,hash_node* c=NULL);
};
hash_node* hash_chain=NULL;
string word;

bool ReadFile(string source);
void PrintContainer();
void CreatHashTable();
int Hash(string &key);
char Cut(char c);
void SearchFor(string word);
void instruction();
void DeleteHashTable();

int main()
{
    if(ReadFile("I_have_a_dream.txt"))
    {
        //PrintContainer();
        CreatHashTable();
        cout<<"Please enter you key: ";
        while((cin>>word)&&word!="END")
        {
            SearchFor(word);
            cout<<"Please enter you key: ";
        }
        DeleteHashTable();
    }
    return 0;
}

bool ReadFile(string source) //��ȡ�ļ����洢
{
    ifstream fin;
    fin.open(source.c_str());
    if(!fin) //���ļ�ʧ��
    {
        cout<<"Unable to open "<<source<<"."<<endl;
        return false;
    }
    //cout<<"open success"<<endl;
    container.clear();
    char buffer[1024]= {0};
    int k=0;
    string temp;
    while(!fin.eof())
    {
        buffer[k++]=fin.get();
        //�Ͼ��������
        if(buffer[k-1]=='.'||buffer[k-1]=='?'||buffer[k-1]=='!')
        {
            temp=buffer;
            container.push_back(temp);
            memset(buffer,0,1024);
            k=0;
            while(!fin.eof())
            {
                if(isalpha(buffer[k]=fin.get()))
                {
                    k=1;
                    break;
                }
            }
        }
    }
    fin.close();
    cout<<"succeed to open "<<source<<"."<<endl;
    return true;
}

void PrintContainer() //��ӡ����������ʹ��
{
    for(int i=0; i<container.size(); i++)
        cout<<container[i]<<endl;
}

int Hash(string &key) //��ϣ stringתint
{
    int seed=31;
    int hash=0;
    int strln=key.length();
    for(int i=0; i<strln; i++)
        hash=(hash*seed+key[i])%HASH_SIZE;
    return hash%HASH_SIZE;
}

char Cut(char c) //�Զ����и��
{
    if(isalpha(c)||c=='\0')
        return c;
    else
        return ' ';
}

void CreatHashTable() //���ɹ�ϣ��
{
    hash_chain=new hash_node [HASH_SIZE];
    for(int i=0; i<HASH_SIZE; i++) //��ʼ��
    {
        hash_chain[i].key="";
        hash_chain[i].number=0;
        hash_chain[i].next=NULL;
    }
    int pos;
    string temp;
    for(int i=0; i<container.size(); i++)
    {
        temp=container[i];//ȥ����β����
        transform(temp.begin(),temp.end(),temp.begin(),Cut);
        //cout<<container[i]<<endl;
        istringstream iss(temp);
        while(iss>>temp) //��ȡ����
        {
            //cout<<temp<<endl;
            pos=Hash(temp);
            hash_node* p1=&hash_chain[pos];
            if(p1->key=="")
            {
                p1->key=temp;
                p1->number=i;
            }
            else
            {
                bool repeat=false;
                while(p1->next!=NULL)
                {
                    if(temp==p1->key&&i==p1->number)
                    {
                        repeat=true;
                        break;
                    }
                    p1=p1->next;
                }
                if(temp==p1->key&&i==p1->number)
                {
                    repeat=true;
                }
                if(repeat)
                    continue;
                hash_node* pnew=new hash_node(temp,i,NULL);
                pnew->next=p1->next;
                p1->next=pnew;
            }
        }
    }
}

hash_node::hash_node(string a,int b,hash_node* c) //�ṹ�幹�캯��
{
    key=a;
    number=b;
    next=c;
}

void SearchFor(string word) //��������
{
    int pos=Hash(word),k=1;
    hash_node* p1=&hash_chain[pos];
    while(p1!=NULL) //��������
    {
        if(p1->key==word)
        {
            cout<<endl;
            cout<<"Sentence "<<k++<<" :"<<endl;
            cout<<container[p1->number]<<endl;
        }
        p1=p1->next;
    }
    cout<<endl;
}

void DeleteHashTable() //ɾ����ϣ��
{
    hash_node *p1,*p2,*p3;
    for(int i=0; i<HASH_SIZE; i++)
    {
        p1=&hash_chain[i];
        p2=p1->next;
        while(p2!=NULL)
        {
            p3=p2->next;
            delete p2;
            p2=p3;
        }
    }
    delete [] hash_chain;
    container.clear();
}
