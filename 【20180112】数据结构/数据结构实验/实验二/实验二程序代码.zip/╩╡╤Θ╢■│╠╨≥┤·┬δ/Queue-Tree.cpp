/*
    1.˳��ѭ������
    2.���������򴴽�
    3.��������α���������ʵ�֣�
    4.�����ʽ������������޽ڵ㴦��*����
*/

#include<stdio.h>
#include<iostream>
#include<malloc.h>
#define MAX 50

using namespace std;


typedef struct BTree
{
    char data;
    struct BTree *lchild,*rchild;
} BiTNode,*BiTree;


typedef struct
{
    BiTree qu[MAX];
    int front,rear;
} Queue;


void CreatBinaryTree(BiTree &T)
{

    char ch;
    scanf("%c",&ch);


    if(ch=='*') T = NULL;
    else
    {

        T=(BiTNode *)malloc(sizeof(BiTNode));
        T->data = ch;
        CreatBinaryTree(T->lchild);
        CreatBinaryTree(T->rchild);
    }
}


void InitQueue(Queue &q)
{
    q.front = 0;
    q.rear = 0;
}


void EnterQueue(Queue &q,BiTree &p)
{

    if((q.rear+1)%MAX != q.front)
    {

        q.qu[q.rear] = p;
        q.rear = (q.rear+1)%MAX;
    }
}


void QuitQueue(Queue &q,BiTree &p)
{

    if(q.front != q.rear)
    {
        p = q.qu[q.front];
        q.front = (q.front + 1)%MAX;
    }
}
void FloorTraverse(BiTree &T)
{

    BiTree p;
    Queue q;
    p = T;
    InitQueue(q);
    if(p)
    {

        EnterQueue(q, p);
        while(q.front != q.rear)
        {

            QuitQueue(q,p);
            cout<<p->data;
            if(p->lchild)
                EnterQueue(q,p->lchild);
            if(p->rchild)
                EnterQueue(q,p->rchild);
        }
    }
}


int main()
{
    BiTree T;
    CreatBinaryTree(T);
    FloorTraverse(T);
    return 0;
}
