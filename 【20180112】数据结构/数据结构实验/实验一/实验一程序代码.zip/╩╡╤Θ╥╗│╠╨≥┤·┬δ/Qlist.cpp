#include"Qlist.h"
#include<iostream>
using namespace std;
int main()
{
    QlistMenu();
    QlistChoose();
    return 0;
}

