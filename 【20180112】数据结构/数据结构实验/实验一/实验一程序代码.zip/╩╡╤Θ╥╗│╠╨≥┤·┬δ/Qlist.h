//The word "List" is so common, in order to prevent duplicate named "Qlist".
#ifndef QLIST_H
#define QLIST_H
#include<iostream>
#include<cstdlib>
#include<vector>
using namespace std;

template<class T>
struct LinkNode
{
    T data;
    LinkNode<T> *link;
    LinkNode(LinkNode<T> *ptr = NULL)
    {
        link = ptr;
    }
    LinkNode(const T item,LinkNode<T> *ptr = NULL)
    {
        data = item;
        link = ptr;
    }

};

template<class T>
class Qlist: public LinkNode<T>
{
public:
    Qlist();
    Qlist(const T x);
    Qlist(Qlist<T>&L);
    ~Qlist();
    void MakeEmpty();
    int Length()const; //length of the linear
    int Search(T x)const; //search x in the linear and return its order number
    LinkNode<T> *Locate(int i);
    T GetData(int i); //get i th order's data
    bool SetData(int i,T x); //change  i th order's data to x
    bool DeleteData(int i);
    bool InsertData(int i,T x);
    void output(bool a,int b,int c); //print the linear

protected:
    LinkNode<T> *first;
};


template<class T>
Qlist<T>::Qlist()
{
    first = new LinkNode<T>;
}

template<class T>
Qlist<T>::Qlist(const T x)
{
    first = new LinkNode<T>(x);
}

template<class T>
Qlist<T>::Qlist(Qlist<T>&L)
{
    T value;
    LinkNode<T>*src = L.getHead();
    LinkNode<T>*des  = first = new LinkNode<T>;
    while(src->link != NULL)
    {
        value = src->link->data;
        des->link = new LinkNode<T>(value);
        des = des->link;
        src = src->link;
    }
    des->link = NULL;
}

template<class T>
Qlist<T>::~Qlist()
{
    MakeEmpty();
};


template<class T>
void Qlist<T>::MakeEmpty()
{
    LinkNode<T> *q;
    while(first->link != NULL)
    {
        q = first->link;
        first->link = q->link;
        delete q;
    }
}

template<class T>
int Qlist<T>::Length()const
{
    LinkNode<T> *p = first->link;
    int counts = 0;
    while(p != NULL)
    {
        p = p->link;
        counts++;
    }
    return counts;
}

template<class T>
LinkNode<T> *Qlist<T>::Locate(int i)
{
    if(i<=0) return NULL;
    else
    {
        LinkNode<T> *current = first;
        int k=0;
        while(current != NULL && k<i)
        {
            current = current->link;
            k++;
        }
        return current;
    }
}

template<class  T>
int Qlist<T>::Search(T x)const
{
    int counts = 0,i = 0;
    LinkNode<T>*current = first->link;
    while(current != NULL)
    {
        if(current->data == x)
        {
            cout<<"Find "<<++counts<<"th \""<<x<<"\" at "<<++i<<"."<<endl;
            current = current->link;
        }
        else
        {
            current = current->link;
            ++i;
        }
    }
    return counts;
}


template<class T>
T Qlist<T>::GetData(int i)
{
    if(i<=0)
    {
        cerr<<"The number is too small!"<<endl;
        return 0;
    }
    LinkNode<T>*current = Locate(i);
    if(current == NULL)
    {
        cerr<<"The number is too large!"<<endl;
        return 0;
    }
    else
    {
        return current->data;
    }
}


template<class T>
bool Qlist<T>::SetData(int i,T x)
{
    if(i <= 0)
    {
        cerr<<"The number is too small!"<<endl;
        return false;
    }
    LinkNode<T>*current = Locate(i);
    if(current == NULL)
    {
        cerr<<"The number is too large!"<<endl;
        return false;
    }
    else current->data = x;
}


template<class T>
bool Qlist<T>::InsertData(int i,T x)
{
    LinkNode<T>* current = Locate(i-1);
    if(i == 1 && first->link == NULL)
    {
        current = new LinkNode<T>(x);
        current->data = x;
        first->link = current;
        current->link = NULL;
        cout<<"OK1"<<endl;
    }
    else if(i != 1 && current == NULL)
    {
        cerr<<"The number is too large!"<<endl;
        return false;
    }
    else
    {
        LinkNode<T>* NewNode = new LinkNode<T>(x);
        if(NewNode == NULL)
        {
            cerr<<"Memory error!"<<endl;
            return false;
        }

        else
        {
            NewNode->link = current->link;
            cout<<"OK2"<<endl;
            current->link = NewNode;
            return true;
        }
    }
}


template <class T>
bool Qlist<T>::DeleteData(int i)
{
    LinkNode<T>*current = Locate(i-1);
    if(i == 1)
    {
        //first->link = current ->link;
    }
    else if(current == NULL || current->link == NULL)
    {
        cerr<<"Delete error!"<<endl;
        return false;
    }
    LinkNode<T>*del = current->link;
    current->link = del->link;
    delete del;
    return true;
}


template<class T>
void Qlist<T>::output(bool a,int b,int c)
{

    if(b>0 && c<= Length())
    {
        if(a == false)
            for(LinkNode<T> *current = Locate(b); current != Locate(c); cout<<current->data<<",", current = current->link);
        if(a == true)
        {
            vector<T> Cache;
            int i = 0;
            for(LinkNode<T> *current2 = Locate(b); current2 != Locate(c); Cache[i]=current2->data,current2 = current2->link);
            for(; i>=1; cout<<Cache[i]<<",",i--);
        }
        cout<<endl;
    }
    else cerr<<"Input error!"<<endl;
}


void QlistMenu()
{
    cout<<"        ----------------------------------------------------------"<<endl;
    cout<<"           1.Insert a Data(eg:1,d)"<<endl;
    cout<<"           2.Set a Data(eg:2 x)"<<endl;
    cout<<"           3.Delete a Data(eg:3)"<<endl;
    cout<<"           4.Get a Data from the list(eg:2)"<<endl;
    cout<<"           5.Search the Data(eg:Andy)"<<endl;
    cout<<"           6.Length of the list"<<endl;
    cout<<"           7.Print somethings(order,begin,end)"<<endl;
    cout<<"           order=0 is postive and 1 is reverse.(eg:0 0 2)"<<endl;
    cout<<"           8.Exit"<<endl;
    cout<<"        ---------------------------------------------------------"<<endl;
}

void QlistChoose()
{
    Qlist<char> A(0);
    while(1)
    {

        int c,a,b;
        char ctr;
        cin>>c;
        switch(c)
        {
        case 1:
        {
            cin>>a>>ctr;
            A.InsertData(a,ctr);
            A.output(0,1,A.Length());
            break;
        }
        case 2:
        {
            cin>>a>>ctr;
            A.SetData(a,ctr);
            A.output(0,1,A.Length());
            break;
        }
        case 3:
        {
            cin>>a;
            A.DeleteData(a);
            A.output(0,1,A.Length());
            break;
        }
        case 4:
        {
            cin>>a;
            cout<<A.GetData(a)<<endl;
            break;
        }
        case 5:
        {
            cin>>ctr;
            A.Search(ctr);
            break;
        }
        case 6:
        {
            cout<<A.Length()<<endl;
            break;
        }
        case 7:
        {
            bool boo;
            cin>>boo>>a>>b;
            A.output(boo,a,b);
            break;
        }
        case 8:
        {
            exit(1);
            break;
        }
        default:
        {
            cerr<<"Input error!"<<endl;
            A.output(0,1,A.Length());
            break;
        }
        }
    }

}


#endif // QLIST_H
