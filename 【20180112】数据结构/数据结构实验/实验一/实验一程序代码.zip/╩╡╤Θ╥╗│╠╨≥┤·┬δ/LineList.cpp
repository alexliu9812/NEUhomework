#include"LinearList.h"
#include<iostream>
using namespace std;
int main()
{
    LinearListMenu();
    LinearListChoose();
    return 0;
}
