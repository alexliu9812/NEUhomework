#ifndef LINEARLIST_H
#define LINEARLIST_H

#include<iostream>
#include<cstdlib>
using namespace std;
const int default_size = 2018;


template<class T>
class LinearList
{
public:
    LinearList(int sz =  default_size);
    ~LinearList();
    int Length()const; //length of the linear
    int Search(T x)const; //search x in the linear and return its order number
    T GetData(int i)const; //get i th order's data
    bool SetData(int i,T x); //change  i th order's data to x
    bool DeleteData(int i);
    bool InsertData(int i,T x);
    void output(bool a,int b,int c); //print the linear
    void ReSize(int new_size);

private:
    T *data;
    int max_size,last_data;
};


template<class T>
LinearList<T>::LinearList(int sz)
{
    if(sz>0)
    {
        max_size = sz;
        last_data=-1;
        data=new T[max_size];
        if(data == NULL)
        {
            cerr<<"Memory creat error!"<<endl;
            exit(1);
        }
    }
    else
    {
        cerr<<"Size error!"<<endl;
        exit(1);
    }
}


template<class T>
LinearList<T>::~LinearList()
{
    delete []data;
};


template<class T>
int LinearList<T>::Length()const
{
    return last_data+1;
}


template<class  T>
int LinearList<T>::Search(T x)const
{
    int counts=0;
    for(int i = 0; i <= last_data; i++)
    {
        if(data[i] == x)
        {
            cout<<"Find "<<++counts<<"th \""<<x<<"\" at "<<i+1<<"."<<endl;
        }
    }
    if(counts>0)
        return 1;
    else
    {
        cerr<<"No this data!"<<endl;
        return 0;
    }
}


template<class T>
T LinearList<T>::GetData(int i)const
{
    if(i>last_data+1 || i<=0)
    {
        cerr<<"The number is error!"<<endl;
        return 0;
    }
    else
    {
        return data[i-1];
    }
}


template<class T>
bool LinearList<T>::SetData(int i,T x)
{
    if(i>0 && i<=last_data+1)
    {
        data[i-1] = x;
        return true;
    }
    else
    {
        cerr<<"The number is error!"<<endl;
        return false;
    }
}


template<class T>
bool LinearList<T>::InsertData(int i,T x)
{
    if(last_data == max_size-1)
    {
        cerr<<"The linear is full!"<<endl;
        return false;
    }
    else if(i>0 && i<=last_data+1)
    {
        for(int j=last_data; j>=i-1; j--)
            data[j+1] = data[j];
        data[i-1] = x;
        last_data++;
        return true;
    }
    else if(i ==1 && last_data == -1)
    {
        data[0]=x;
        last_data++;
        return true;
    }
    else
    {
        cerr<<"input error!"<<endl;
        return false;
    }
}


template <class T>
bool LinearList<T>::DeleteData(int i)
{
    if(i>0 && i<=last_data+1)
    {
        for(int j=i-1; j<last_data; j++)
            data[j]=data[j+1];
        last_data--;
        return true;
    }
    else
    {
        return false;
    }
}


template<class T>
void LinearList<T>::output(bool a,int b,int c)
{
    if((a==0 || a==1) && b>0 && c<=last_data+1)
    {
        if(a == false)for(int i=b-1; i<c; cout<<data[i]<<",", i++);
        else if(a == true)for(int i=c-1; i>=b-1; cout<<data[i]<<",", i--);
    }
    else cerr<<"Input error!"<<endl;
    cout<<endl;
}


template<class T>
void LinearList<T>::ReSize(int new_size)
{
    if(new_size < last_data+1 || new_size >= 2147483647)
    {
        cerr<<"New Memory too small or large!"<<endl;
    }
    else
    {
        T *new_array = new T[new_size];
        if(new_array == NULL)
        {
            cerr<<"New memory creat error!"<<endl;
            exit(1);
        }
        int n = last_data + 1;
        T *srcptr = data;
        T *destptr = new_array;
        while(n--) *destptr++=*srcptr++;
        delete []data;
        data = new_array;
        max_size = new_size;
        cout<<"Successfully adjust the size!"<<endl;
    }
}

void LinearListMenu()
{
    cout<<"        ----------------------------------------------------------"<<endl;
    cout<<"           1.Insert a Data(eg:1,d)"<<endl;
    cout<<"           2.Set a Data(eg:2 x)"<<endl;
    cout<<"           3.Delete a Data(eg:3)"<<endl;
    cout<<"           4.Get a Data from the list(eg:2)"<<endl;
    cout<<"           5.Search the Data(eg:Andy)"<<endl;
    cout<<"           6.Length of the list"<<endl;
    cout<<"           7.Print somethings(order,begin,end)"<<endl;
    cout<<"           order=0 is postive and 1 is reverse.(eg:0 0 2)"<<endl;
    cout<<"           8.Adjust the size of the list(eg:2018)"<<endl;
    cout<<"           9.Exit"<<endl;
    cout<<"        ---------------------------------------------------------"<<endl;
}

void LinearListChoose()
{
    LinearList<char> A;
    while(1)
    {

        int c,a,b;
        char ctr;
        cin>>c;
        switch(c)
        {
        case 1:
        {
            cin>>a>>ctr;
            A.InsertData(a,ctr);
            A.output(0,1,A.Length());
            break;
        }
        case 2:
        {
            cin>>a>>ctr;
            A.SetData(a,ctr);
            A.output(0,1,A.Length());
            break;
        }
        case 3:
        {
            cin>>a;
            A.DeleteData(a);
            A.output(0,1,A.Length());
            break;
        }
        case 4:
        {
            cin>>a;
            cout<<A.GetData(a)<<endl;
            break;
        }
        case 5:
        {
            cin>>ctr;
            A.Search(ctr);
            break;
        }
        case 6:
        {
            cout<<A.Length()<<endl;
            break;
        }
        case 7:
        {
            bool boo;
            cin>>boo>>a>>b;
            A.output(boo,a,b);
            break;
        }
        case 8:
        {
            cin>>a;
            A.ReSize(a);
            break;
        }
        case 9:
            {
                exit(1);
                break;
            }
        default:
        {
            cerr<<"Input error!"<<endl;
            A.output(0,1,A.Length());
            break;
        }
        }
    }

}

#endif
