#ifndef STACK_H
#define STACK_H

const int maxSize = 500;
template<class T>
class Stack
{
public:
    Stack(){};
    virtual void Push(const T x) = 0;
    virtual void Pop(T x) = 0;
    virtual T GetTop(T x)const =0;
    virtual int GetSize()const = 0;
};
#endif // STACK_H
