#ifndef SQELIST_H
#define SQELIST_H

#include<iostream>
#include<cstdlib>
using namespace std;
const int default_size=2018;

template<class T>
class SeqList{

}

#endif
