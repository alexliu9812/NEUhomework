#include"LinkedList.h"
#include<iostream>
#include<cmath>
using namespace std;
const int n = 20;
int main()
{
    LinkedList<int> A;
    cout<<"��ջ��ϡ�"<<endl;
    if(A.IsEmpty()==true)cout<<"A is Empty."<<endl;
    for(int i=0; i<n; i++)
        A.Push(i);
    cout<<"��ջ��ϡ�"<<endl;
    cout<<"ջ����"<<A.GetSize()<<endl;
    for(int i=0; i<3; cout<<A.Pop()<<" ",i++);
    cout<<endl;
    cout<<"��ջ��ϡ�"<<endl;

    //��������ת��
    {
        A.Empty();
        int num,a,b;
        cout<<"Input num,its hex and target hex:(Eg.621 10 8)"<<endl;
        cin>>num>>a>>b;
        int i,counts=0,sum=0;
        while(num!=0)
        {
            i=num%10;
            sum=sum+i*pow(float(a),float(counts));
            num/=10;
            counts++;
        }
        while(sum!=0)
        {
            i=sum%b;
            A.Push(i);
            sum/=b;
        }
        for(; A.GetSize()>0; cout<<A.Pop()<<" ");
        cout<<endl;
    }

    //����ʽ���ż��
//check("(s+7*(7+d)+(ss/ds))");
//check("(d+9^(ds_ds)sd)ds)");
    check();
    return 0;
}
