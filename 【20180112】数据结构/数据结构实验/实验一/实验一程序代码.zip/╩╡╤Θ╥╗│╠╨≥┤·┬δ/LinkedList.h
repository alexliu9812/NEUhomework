#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include<iostream>
using namespace std;

template<class T>
struct LinkNode
{
    T data;
    LinkNode<T> *link;
    LinkNode(LinkNode<T> *ptr = NULL)
    {
        link = ptr;
    }
    LinkNode(const T item,LinkNode<T> *ptr = NULL)
    {
        data = item;
        link = ptr;
    }
};

template<class T>
class LinkedList
{
public:
    LinkedList():head(NULL) {};
    ~LinkedList()
    {
        Empty();
    };
    void Empty();
    void Push(const T x);
    T Pop();
    bool IsEmpty()const;
    T GetTop()const;
    int GetSize()const;
private:
    LinkNode<T> *head;
};

template<class T>
void LinkedList<T>::Empty()
{
    LinkNode<T> *p;
    while(head!=NULL)
    {
        p=head;
        head=head->link;
        delete p;
    }
}

template<class T>
void LinkedList<T>::Push(const T x)
{
    head = new LinkNode<T>(x,head);
}

template<class T>
T LinkedList<T>::Pop()
{
    if(IsEmpty()!=true)
    {
        LinkNode<T>*p;
        p=head;
        head=head->link;
        return (p->data);
    }
}

template<class T>
bool LinkedList<T>::IsEmpty()const
{
    if(head == NULL)
        return true;
    else return false;
}

template<class T>
T LinkedList<T>::GetTop()const
{
    if(IsEmpty()== true)
    {
        cerr<<"No data."<<endl;
        return NULL;
    }
    else
    {
        LinkNode<T> *p;
        p=head;
        cout<<p->data<<endl;
        return p->data;
    }
}

template<class T>
int LinkedList<T>::GetSize()const
{
    int counts=0;
    LinkNode<T>*p;
    p=head;
    for(; p!=NULL; p=p->link,counts++);
    return counts;
}

void check()
{
        char str[100],s[100],c;
        int i=0,j=0,flag=1;
        for(; (cin>>c) != NULL && i<100; str[i]=c,i++);
        for(; i>=0; i--)
            if(str[i]=='('||str[i]==')')
                s[j++]=str[i];

        for(int k=j; k>=0; k--)
        {

            if(s[k]=='(')
                for(int i=k; i>=0; i--)
                {
                    if(s[i]==')')
                    {
                        s[i]='0';
                        break;
                    }
                }
            if(s[k]==')')
            {
                cout<<"Error."<<endl;
                flag=0;
                break;
            }
        }
        if(flag!=0)cout<<"Right"<<endl;

}
#endif // LINKEDLIST_H
