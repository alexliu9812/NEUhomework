#ifndef SEQSTACK_H
#define SEQSTACK_H
#include <iostream>
#include <assert.h>
//#include "Stack.h"
const int stackIncrease = 200;
const int maxSize = 500;
using namespace std;

template<class T>
class SeqStack
{
public:
    SeqStack(int sz = 100);
    ~SeqStack();
    void Empty();
    void OverFlow();
    void Push(const T x);
    T Pop();
    bool IsFull()const;
    bool IsEmpty()const;
    T GetTop()const;
    int GetSize()const;
private:
    T *elements;
    int top,maxSize;
};

template<class T>
SeqStack<T>::SeqStack(int sz):top(-1),maxSize(sz)
{
    elements = new T[maxSize];
    assert(elements != NULL);
}

template<class T>
SeqStack<T>::~SeqStack()
{
    delete []elements;
}

template<class T>
void SeqStack<T>::OverFlow()
{
    T *new_arr = new T[maxSize+stackIncrease];
    if(new_arr == NULL)
    {
        cerr<<"Memory error!"<<endl;
    }
    for(int i = 0; i<=top; i++)
        new_arr[i]=elements[i];
    maxSize+=stackIncrease;
    delete []elements;
    elements = new_arr;
}

template<class T>
bool SeqStack<T>::IsFull()const
{
    return ((top == maxSize-1)?1:0);
}

template<class T>
bool SeqStack<T>::IsEmpty()const
{
    return ((top == -1)?1:0);
}

template<class T>
int SeqStack<T>::GetSize()const
{
    return (top+1);
}

template<class T>
void SeqStack<T>::Push(const T x)
{
    if(IsFull() == true)OverFlow();
    elements[++top]=x;
}

template<class T>
T SeqStack<T>::Pop()
{
    if(IsEmpty() != true)
        return elements[top--];
}

template<class T>
T SeqStack<T>::GetTop()const
{
    if(IsEmpty()!=true)
        return elements[top];
}

template<class T>
void SeqStack<T>::Empty()
{
    top = -1;
}


void check()
{
        char str[100],s[100],c;
        int i=0,j=0,flag=1;
        for(; (cin>>c) != NULL && i<100; str[i]=c,i++);
        for(; i>=0; i--)
            if(str[i]=='('||str[i]==')')
                s[j++]=str[i];

        for(int k=j; k>=0; k--)
        {

            if(s[k]=='(')
                for(int i=k; i>=0; i--)
                {
                    if(s[i]==')')
                    {
                        s[i]='0';
                        break;
                    }
                }
            if(s[k]==')')
            {
                cout<<"Error."<<endl;
                flag=0;
                break;
            }
        }
        if(flag!=0)cout<<"Right"<<endl;

}
#endif // SEQSTACK_H
